// Fungsi untuk menginisialisasi peta Google
function initMap() {
  var location = { lat: -6.123456, lng: 106.789012 }; // Koordinat lokasi Anda
  var map = new google.maps.Map(document.getElementById("map"), {
    zoom: 15,
    center: location,
  });
  var marker = new google.maps.Marker({
    position: location,
    map: map,
  });
}

// for collor change
const btn = document.getElementById("btn");
let hex = document.getElementById("hexCode");
// pop up
function openPopup(imageSrc) {
  document.getElementById('popupImage').src = imageSrc;
  document.getElementById('popup').style.display = 'block';
}

function closePopup() {
  document.getElementById('popup').style.display = 'none';
}

